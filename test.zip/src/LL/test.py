import playerLL

if "__main__" == "__name__":
    test_player : playerLL(.....)
    test_player.check_player_team