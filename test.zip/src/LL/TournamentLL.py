from datetime import datetime
from models.tournament import TournamentLL
from models.team import Team
from IO.data_wrapper import DLWrapper


class Tournament:
    def __init__(self, dl_wrapper: DLWrapper):
        self._dl_wrapper = dl_wrapper

    def create_tournament(self, tournament: TournamentLL):
        validate_errors = self.validate_tournament(tournament)


        # TODO: Route to data storage
        if validate_errors:
            return validate_errors
        else:
            #return "Successfully created tournament."
            return self._dl_wrapper.create_tournament(tournament)

        # TODO: Generate schedule
        # schedule = GenerateTournamentSchedule(tournament).generate()

       

    def register_teams(self, tournament: TournamentLL, teams: list[str]):
        # TODO: Implement team registration logic
        pass




    # ----------------------------------------------------------------------
    # VALIDATION HELPERS 
    # ----------------------------------------------------------------------



    # ----------------------------------------------------------------------    
     # tournament name validation
    # ----------------------------------------------------------------------
    
    def check_tournament_name(self, tournament: TournamentLL):
        self.name = tournament.name.strip()

        if len(self.name) == 0:
            return "Tournament name cannot be empty."

        if len(self.name) < 3 or len(self.name) > 60:
            return "Tournament name must be between 3–60 characters."

        return True


# ----------------------------------------------------------------------
 # tournament type validation
# ----------------------------------------------------------------------


    def check_tournament_type(self,tournament: TournamentLL):
        self.tournament_type = tournament.tournament_type.strip()

        allowed_names = ["Knockout", "Double Elimination"]

        if self.tournament_type not in allowed_names:
            return "Tournament type must be 'Knockout' or 'Double Elimination'."

        return True


    # ----------------------------------------------------------------------
     # date validation
    # ----------------------------------------------------------------------

    def check_dates(self, tournament: TournamentLL):
        try:
            self.start = datetime.strptime(tournament.start_date, "%Y.%m.%d")
            self.end = datetime.strptime(tournament.end_date, "%Y.%m.%d")
        except ValueError:
            return "Invalid date format. Use yyyy.mm.dd"

        if self.start >= self.end:
            return "Start date must be before end date."

        if (self.end - self.start).days != 2:
            return "Tournament must span exactly 3 days."

        return True

    # ----------------------------------------------------------------------
    # VALIDATE TOURNAMENT 
    # ----------------------------------------------------------------------

    def validate_tournament(self, tournament: TournamentLL):
        errors = []

        check_name = Tournament.check_tournament_name(tournament)
        check_type = Tournament.check_tournament_type(tournament)
        check_dates = Tournament.check_dates(tournament)

        if check_name is not True:
            errors.append(f"Name: {check_name}")

        if check_type is not True:
            errors.append(f"Type: {check_type}")

        if check_dates is not True:
            errors.append(f"Dates: {check_dates}")

        return errors if errors else None


# --------------------------------------------------------------------------
# TEAM REGISTRATION CLASS 
# --------------------------------------------------------------------------

class RegisterTeam:
    """
    Helper class for managing team registration in a tournament.
    """

    def __init__(self, team_name: str, captain_name: str):
        self.team_name = team_name
        self.captain_name = captain_name
        self.players = []

    def add_player(self, player_name: str):
        if player_name in self.players:
            return "Player is already in the team."

        self.players.append(player_name)
        return True


# --------------------------------------------------------------------------
# SCHEDULING CLASS 
# --------------------------------------------------------------------------

class GenerateTournamentSchedule:
    """
    Helper class for generating tournament schedules.
    """

    def __init__(self, tournament_data: dict):
        self.tournament_data = tournament_data
        self.schedule = []

    def generate(self):
        tournament_type = self.tournament_data.get("type", "").lower()

        if tournament_type == "round robin":
            return self._round_robin()

        if tournament_type == "knockout":
            return self._knockout()

        return []

    # TODO: Implement these properly
    def _round_robin(self):
        teams = self.tournament_data.get("teams", [])
        schedule = []
        # Each team plays every other team once → TODO
        return schedule

    def _knockout(self):
        teams = self.tournament_data.get("teams", [])
        schedule = []
        # Single-elimination bracket → TODO
        return schedule
