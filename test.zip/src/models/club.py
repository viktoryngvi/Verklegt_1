
class Club:
    def __init__(self, name: str, home_town: str, country: str, colors: list):
        self.name = name
        self.home_town = home_town
        self.country = country
        self.colors = colors
        pass

